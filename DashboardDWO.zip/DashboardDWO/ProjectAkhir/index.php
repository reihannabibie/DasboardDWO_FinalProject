<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Style -->
  <!-- <link rel="stylesheet" href="css/style.css"> -->

  <title>Login</title>
</head>
<style>
  body {
  font-family: 'Roboto', sans-serif;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
}

.content {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  overflow: hidden;
  width: 90%;
  max-width: 900px;
  display: flex;
  flex-direction: row;
}

.col-md-6 {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.col-md-6 img {
  max-width: 70%;
  border-radius: 10px;
}

.contents {
  padding: 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  background: #f9f9f9;
}

h1 {
  font-size: 36px;
  font-weight: bold;
  text-align: center;
  color: #333;
}

p {
  color: #555;
  font-size: 14px;
  margin: 10px 0;
  text-align: center;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #333;
}

.form-control {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
  transition: all 0.3s;
}

.form-control:focus {
  border-color: #2575fc;
  box-shadow: 0 0 8px rgba(37, 117, 252, 0.5);
}

.btn {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  color: #fff;
  padding: 12px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  text-transform: uppercase;
  transition: background 0.3s;
}

.btn:hover {
  background: linear-gradient(135deg, #2575fc 0%, #6a11cb 100%);
}

footer {
  margin-top: 20px;
  text-align: center;
  font-size: 14px;
  color: #777;
}

footer a {
  color: #2575fc;
  text-decoration: none;
}

footer a:hover {
  text-decoration: underline;
}

</style>
<body>

  <?php

  if (!empty($_POST)) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == "admin" && $password == "admin") {
      header("location:home.php");
    }
  }


  ?>

  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <img src="images/logo.jpeg" alt="Image" class="img-fluid">
        </div>
        <div class="col-md-8 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
                <h1><b>L O G I N</b></h1>
                <p class="mb-4">DASHBOARD ADVENTURE WORK</p>
              </div>
              <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <p style="color: black;">Username :</p>
                <div class="form-group first">
                  <label for="username">Username</label>
                  <input type="text" class="form-control" id="username" name="username">

                </div>
                <p style="color: black;">Passsword :</p>
                <div class="form-group last mb-4">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" id="password" name="password">

                </div>
                <!-- 
              <div class="d-flex mb-5 align-items-center">
                <label class="control control--checkbox mb-0"><span class="caption">Remember me</span>
                  <input type="checkbox" checked="checked"/>
                  <div class="control__indicator"></div>
                </label>
                <span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span> 
              </div>
              -->
                <input type="submit" value="Login" class="btn btn-block btn-success">
              </form>
            </div>
          </div>

        </div>

      </div>
    </div>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
</body>

</html>