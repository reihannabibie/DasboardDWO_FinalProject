<?php
// Konfigurasi koneksi database
require('koneksipurchase.php');

// Query untuk mendapatkan rata-rata jumlah pembelian per vendor
$sql = "
    SELECT 
        v.VendorCompanyName AS vendor_name,
        AVG(fp.AmountPurchase) AS avg_purchase
    FROM fact_purchase fp
    JOIN vendor v ON fp.VendorID = v.VendorID
    GROUP BY v.VendorCompanyName
    ORDER BY avg_purchase DESC
";

$result = $conn->query($sql);

$data = [];

// Memasukkan hasil query ke dalam array
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            'vendor_name' => $row['vendor_name'],
            'avg_purchase' => round($row['avg_purchase'], 2) // Pembulatan nilai rata-rata
        ];
    }
} else {
    $data = [
        'error' => $conn->error ?: 'Tidak ada data ditemukan.'
    ];
}

// Mengatur header untuk format JSON
header('Content-Type: application/json');

// Mengembalikan data dalam format JSON
echo json_encode($data);

// Menutup koneksi
$conn->close();
?>
