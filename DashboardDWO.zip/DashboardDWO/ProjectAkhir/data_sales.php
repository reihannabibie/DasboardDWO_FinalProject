<?php
require('koneksisales.php'); // Koneksi database

// Query untuk mengambil total penjualan setiap bulan
$sql = "SELECT dt.Bulan AS bulan, 
               SUM(fs.SalesAmount) AS total_penjualan
        FROM factsales fs
        JOIN dime_time dt ON fs.TimeID = dt.TimeID
        GROUP BY dt.Bulan
        ORDER BY dt.Bulan";

$result = mysqli_query($conn, $sql);

$data_sales = array();

while ($row = mysqli_fetch_assoc($result)) {
    $data_sales[] = array(
        "bulan" => $row['bulan'],
        "total_penjualan" => $row['total_penjualan']
    );
}

echo json_encode($data_sales); // Mengirim data dalam format JSON
?>
