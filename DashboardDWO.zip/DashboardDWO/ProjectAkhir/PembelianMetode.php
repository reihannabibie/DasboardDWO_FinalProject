<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard Adventure Work</title>

    <!-- Custom fonts for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.3/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styleGraph.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Chart.js Data Labels Plugin -->
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar (optional) -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard Adventure Work</h1>
                </nav>

                <!-- Main Content -->
                <div class="container-fluid">
                    <!-- Grafik Pembelian -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Grafik Total Pembelian berdasarkan Metode Pengiriman</h6>
                        </div>
                        <div class="card-body">
                            <!-- Increased canvas size for a larger doughnut chart -->
                            <canvas id="donutChart" width="250" height="250"></canvas> <!-- Slightly larger size -->
                        </div>
                    </div>
                </div>
            </div>
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Dashboard Reihan & Irfan</span>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script>
        // Mendapatkan data dari file PHP menggunakan URL yang benar
        fetch('data_ShipMethod.php') 
            .then(response => {
                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    throw new Error(data.error);
                }

                // Mengolah data untuk Chart.js
                const labels = data.map(item => item.shipname); // Nama metode pengiriman
                const totalPurchases = data.map(item => item.total_purchase); // Total pembelian

                const colors = [
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(153, 102, 255, 0.7)'
                ];

                const ctx = document.getElementById('donutChart').getContext('2d'); // Get context for the canvas
                const myDoughnutChart = new Chart(ctx, {
                    type: 'doughnut', // Specify doughnut chart type
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Total Pembelian',
                            data: totalPurchases,
                            backgroundColor: colors,
                            borderColor: colors.map(color => color.replace('0.7', '1')),
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'top'
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `${context.label}: ${context.raw.toLocaleString('id-ID', {style: 'currency', currency: 'IDR'})}`;
                                    }
                                }
                            },
                            datalabels: { // Configuration for data labels
                                color: '#fff',
                                formatter: (value, context) => {
                                    return value.toLocaleString('id-ID', {style: 'currency', currency: 'IDR'});
                                },
                                anchor: 'end',
                                align: 'end'
                            }
                        }
                    }
                });
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Gagal mengambil data: ' + error.message);
            });
    </script>
</body>

</html>
