Berikut adalah file yang digunakan dalam menyelesaikan proyek akhir mata kuliah Data Warehouse dan OLAP.

Program Studi: Sistem Informasi  
Fakultas: Ilmu Komputer  
Universitas: Pembangunan Nasional "Veteran" Jawa Timur

Anggota Kelompok:
<1. Reihan Nabibie (22082010170)  
<2. Irfan Rizky Anugrah (24082910274)

Catatan Penting:  
<1. OLAP.zip berisi folder untuk menampilkan OLAP pada bagian sales dan purchase. File ini harus dimasukkan ke dalam folder mondrian.  
<2. pentaho.ktr adalah folder yang digunakan untuk menjalankan Spoon (Pentaho Data Integration), yang berfungsi untuk mengisi tabel fakta pada bagian sales (dwo_uts.sql) dan purchase (project_uas.sql).

Langkah-Langkah Implementasi:  
<1. Buat dua basis data bernama project_uas dan dwo_uts.  
<2. Impor masing-masing SQL dump ke dalam basis data tersebut.  
<3. Ekstrak file ProjectAkhir.zip.  
<4. Pindahkan file hasil ekstraksi ke direktori C:\xampp\htdocs.  
<5. Ekstrak file OLAP.zip.  
<6. Pindahkan file index ke direktori C:\xampp\tomcat\webapps\mondrian. Kemudian, pindahkan file lainnya ke direktori C:\xampp\tomcat\webapps\mondrian\WEB-INF\queries.  
<7. Aktifkan Apache, MySQL, dan Tomcat melalui XAMPP.  
<8. Akses halaman dashboard melalui URL: http://localhost/DashboardDWO/AkhirProject/index.php.  
<9. Gunakan username dan password 'admin' untuk masuk ke sistem.
